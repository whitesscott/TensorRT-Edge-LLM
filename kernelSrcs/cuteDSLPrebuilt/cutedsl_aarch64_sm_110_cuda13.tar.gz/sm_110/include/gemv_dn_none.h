
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} gemv_dn_none_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_gemv_dn_none_cuda_init(void **);
void _mlir_gemv_dn_none_cuda_load_to_device(void **);
static inline void gemv_dn_none_Kernel_Module_Load(gemv_dn_none_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_gemv_dn_none_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_gemv_dn_none_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void gemv_dn_none_Kernel_Module_Unload(gemv_dn_none_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_gemv_dn_none__mlir_ciface_cutlass___call_____main__export_gemv_variantlocals_GemvLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_2688_1856_6_1_CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_gemv_dn_none_wrapper(gemv_dn_none_Kernel_Module_t *module, void *input_ptr, void *input2_ptr, void *weights_ptr, void *scales_ptr, void *global_scales_ptr, void *expert_ids_ptr, void *gate_scores_ptr, void *output_ptr, int32_t K, int32_t N, int32_t topK, int32_t numTokens, cudaStream_t stream) {
    int32_t ret;
    void *args[14] = {
        &input_ptr, &input2_ptr, &weights_ptr, &scales_ptr, &global_scales_ptr, &expert_ids_ptr, &gate_scores_ptr, &output_ptr, &K, &N, &topK, &numTokens, &stream,
        &ret
    };
    _mlir_gemv_dn_none__mlir_ciface_cutlass___call_____main__export_gemv_variantlocals_GemvLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_2688_1856_6_1_CUstream0x0(args, 14);
    return ret;
}
